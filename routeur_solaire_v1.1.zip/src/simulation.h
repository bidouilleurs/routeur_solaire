/***************************************/
/******** Programme simulation   ********/
/***************************************/
#ifndef RA_SIMULATION_H
#define RA_SIMULATION_H

class RASimulationClass
{
public:
  void imageMesure(int tempo);
};
extern RASimulationClass RASimulation;
#endif
