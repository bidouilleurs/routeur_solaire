#ifndef RA_OTA_H
#define RA_OTA_H
class RAOTAClass
{
public:
  void begin();
  void loop();

private:
};

extern RAOTAClass RAOTA;
#endif